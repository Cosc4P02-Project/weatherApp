function Scheduling() {
    return (
        <html>
        <body>
        <p>test</p>
        </body>
        </html>

    );

}