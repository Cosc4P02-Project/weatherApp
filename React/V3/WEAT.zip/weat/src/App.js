import {Routes} from './Routes';

export const App = () => {
    return (
        <Routes/>
    )
}