export const NotFound = () => {
    return (
        <h1>The page does not exist!</h1>
    )
}