import './Styles.css';
export const Accounts = () => {
    return (
        <html>
        <body className={"accounts"}>
        <h1>Accounts</h1>
        </body>
        </html>
    )
}