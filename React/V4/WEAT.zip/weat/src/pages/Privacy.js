import './Styles.css';
export const Privacy = () => {
    return (
        <html>
        <body className={"privacy"}>
        <h1>Privacy</h1>
        </body>
        </html>
    )
}