import './Styles.css';
import format from "date-fns/format";
import React, {useState} from "react";

function getDate() {
    const today = new Date();
    const day = today.getDay();
    const month = today.getMonth();
    const year = today.getFullYear();
    const date = today.getDate();
    return format(new Date(year, month, date, day), 'EEEE MMMM do yyyy');
}

function getTime() {
    const today = new Date();
    const time = today.getTime();
    return format(new Date(time), 'p');
}
function Scheduling() {
    const [currentDate] = useState(getDate());
    const [currentTime] = useState(getTime());
    return (
        <html>
        <body className={"scheduling"}>
        <nav>
            <ul>Toronto</ul>
            <ul>Montreal</ul>
            <ul>New York</ul>
            <ul>London</ul>
        </nav>
        <div id={"searchBar"}>
            <input type={"text"} placeholder={"Search..."}/>
        </div>
        <h4>{currentDate} | Local Time {currentTime}</h4>
        <h2>St. Catharine's ON</h2>
<div id={"center"}>
    <img src={'./icon_weather-sunny_small.png'} alt="Weather storm small"/>
    <img src={'./icon_settings_small.png'} alt="Weather storm small"/>
    <img src={'./icon_route_small.png'} alt="Weather storm small"/>
</div>
        </body>
        </html>
    )
}

export default Scheduling;