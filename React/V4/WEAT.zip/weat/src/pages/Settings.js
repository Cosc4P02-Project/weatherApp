import './Styles.css';
export const Settings = () => {
    return (
        <html>
        <body className={"settings"}>
        <h1>Theme</h1>
        <h1>Accessibility</h1>
        <h1>Privacy</h1>
        <h1>Security</h1>
        <h1>Accounts</h1>
        </body>
        </html>
    )
}