import {BrowserRouter as Router, Switch, Route, Redirect} from 'react-router-dom';
import Scheduling from "./pages/Scheduling";
import {NotFound} from "./pages/NotFound";
import Home from "./pages/Home";
import {Settings} from "./pages/Settings";
import {Accessibility} from "./pages/Accessibility";
import {Theme} from "./pages/Theme";
import {Privacy} from "./pages/Privacy";
import {Security} from "./pages/Security";
import {Accounts} from "./pages/Accounts";

export const Routes = () => {
    return (
        <Router>
            <Switch>
                <Route path={"/"} exact>
                    <Redirect to={"/Home"}/>
                </Route>
                <Route path={"/Home"} exact>
                    <Home/>
                </Route>
                <Route path={"/Scheduling"} exact>
                    <Scheduling/>
                </Route>
                <Route path={"/Settings"} exact>
                    <Settings/>
                </Route>
                <Route path={"/Accounts"} exact>
                    <Accounts/>
                </Route>
                <Route path={"/Security"} exact>
                    <Security/>
                </Route>
                <Route path={"/Privacy"} exact>
                    <Privacy/>
                </Route>
                <Route path={"/Accessibility"} exact>
                    <Accessibility/>
                </Route>
                <Route path={"/Theme"} exact>
                    <Theme/>
                </Route>
                <Route>
                    <NotFound/>
                </Route>
            </Switch>
        </Router>
    )
}