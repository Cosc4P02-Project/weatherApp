import './Styles.css';
export const Accessibility = () => {
    return (
        <html>
        <body className={"accessibility"}>
        <h1>Accessiblity</h1>
        </body>
        </html>
    )
}