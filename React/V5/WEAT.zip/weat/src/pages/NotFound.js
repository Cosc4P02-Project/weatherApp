export const NotFound = () => {
    return (
        <html>
        <body className={"notfound"}>
        <h1>The page does not exist!</h1>
        </body>
        </html>
    )
}