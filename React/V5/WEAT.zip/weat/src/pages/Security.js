import './Styles.css';
export const Security = () => {
    return (
        <html>
        <body className={"security"}>
        <h1>Security</h1>
        </body>
        </html>
    )
}