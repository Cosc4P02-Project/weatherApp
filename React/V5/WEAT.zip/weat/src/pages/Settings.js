import './Styles.css';

export const Settings = () => {
    return (
        <html>
        <body className={"settings"}>
        <a href="" rel="">

        </a>

        <a href="./Theme" rel="theme">
            <h1>Theme</h1>
        </a>

        <a href="./Accessibility" rel="accessibility">
            <h1>Accessibility</h1>
        </a>

        <a href="./Privacy" rel="privacy">
            <h1>Privacy</h1>
        </a>

        <a href="./Security" rel="security">
            <h1>Security</h1>
        </a>

        <a href="./Accounts" rel="accounts">
            <h1>Accounts</h1>
        </a>
        </body>
        </html>
    )
}