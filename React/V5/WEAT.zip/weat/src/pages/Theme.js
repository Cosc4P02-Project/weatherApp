import './Styles.css';
export const Theme = () => {
    return (
        <html>
        <body className={"theme"}>
        <h1>Theme</h1>

        </body>
        </html>
    )
}