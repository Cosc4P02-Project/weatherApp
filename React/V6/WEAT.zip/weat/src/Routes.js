import {BrowserRouter as Router, Switch, Route, Redirect} from 'react-router-dom';
import Scheduling from "./pages/Scheduling";
import {NotFound} from "./pages/NotFound";
import Home from "./pages/Home";
import Settings from "./pages/Settings";

export const Routes = () => {
    return (
        <Router>
            <Switch>
                <Route path={"/"} exact>
                    <Redirect to={"/Home"}/>
                </Route>
                <Route path={"/Home"} exact>
                    <Home/>
                </Route>
                <Route path={"/Scheduling"} exact>
                    <Scheduling/>
                </Route>
                <Route path={"/Settings"} exact>
                    <Settings/>
                </Route>
                <Route>
                    <NotFound/>
                </Route>
            </Switch>
        </Router>
    )
}