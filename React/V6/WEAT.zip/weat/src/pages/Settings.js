import './Styles.css';
import React, {useState, useEffect} from "react";
function refreshPage() {
    window.location.reload(false);
}

function Settings() {
    const [color, setColor] =useState(localStorage.getItem("colorValue"));
    useEffect(()=>{document.body.style.backgroundColor=color},[color])
    const click = color =>{setColor(localStorage.setItem("colorValue",color))}

    return (
        <html>
        <body className={"settings"}>
        <div id={"center"}>
            <h1>Themes</h1>
            <img src={'./icon_theme.svg'} alt="theme"/>
        </div>
        <div id={"center"}>
            <button id={"redButton"} onClick={()=>{click("red"); refreshPage(); }}>Red</button>
            <button id={"yellowButton"} onClick={()=>{click("yellow"); refreshPage(); }}>Yellow</button>
            <button id={"greenButton"} onClick={()=>{click("green"); refreshPage(); }}>Green</button>
            <button id={"blueButton"} onClick={()=>{click("blue"); refreshPage(); }}>Blue</button>
        </div>
        </body>
        </html>
    )
}

export default Settings;