import './Styles.css';
import React, {useEffect, useState} from 'react';
import format from "date-fns/format";

function getDate() {
    const today = new Date();
    const day = today.getDay();
    const month = today.getMonth();
    const year = today.getFullYear();
    const date = today.getDate();
    return format(new Date(year, month, date, day), 'EEEE MMMM do yyyy');
}

function Home() {
    const [currentDate] = useState(getDate());
    /*useEffect(()=>{
        localStorage.setItem("colorValue","#503cb4")
    }, [])*/

    const [color] =useState(localStorage.getItem("colorValue"));
    useEffect(()=>{document.body.style.backgroundColor=color},[color])

    return (
        <html>
        <body className={"home"}>
        <p class="upperLeft">WEAT</p>
        <h1>Your WEAT Schedule</h1>
        <h1>{currentDate}</h1>
        <div id={"center"}>
            <text id={"bold"}>0&deg;C</text>
            <img src={'./icon_weather-storm_small.png'} alt="Weather storm small"/>
            <text id={"bold"}>5&deg;C</text>
            <img src={'./icon_weather-rain_small.png'} alt="Weather storm small"/>
            <text id={"bold"}>10&deg;C</text>
            <img src={'./icon_weather-snow_small.png'} alt="Weather storm small"/>
            <p></p>
            <text id={"bold"}>7&deg;C</text>
            <img src={'./icon_weather-cloudy_small.png'} alt="Weather storm small"/>
            <text id={"bold"}>4&deg;C</text>
            <img src={'./icon_weather-sunny_small.png'} alt="Weather storm small"/>
            <text id={"bold"}>3&deg;C</text>
            <img src={'./icon_weather-windy_small.png'} alt="Weather storm small"/>
        </div>
        </body>
        </html>
    );
}

export default Home;
