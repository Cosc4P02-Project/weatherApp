import {useEffect, useState} from "react";

export const NotFound = () => {
    const [color] =useState(localStorage.getItem("colorValue"));
    useEffect(()=>{document.body.style.backgroundColor=color},[color])
    return (
        <html>
        <body className={"notfound"}>
        <h1>The page does not exist!</h1>
        </body>
        </html>
    )
}